
-- Enums
create type public.app_role as enum ('super_admin', 'admin', 'sales');
create type public.lead_status as enum ('new','contacted','follow_up','qualified','proposal_sent','negotiation','converted','rejected');
create type public.lead_priority as enum ('low','medium','high','urgent');

-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  avatar_url text,
  job_title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "Profiles readable by authenticated" on public.profiles for select to authenticated using (true);
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id);
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);

-- User roles
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users view all roles" on public.user_roles for select to authenticated using (true);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- Auto-create profile + default role on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    new.raw_user_meta_data->>'avatar_url'
  );
  -- First user becomes super_admin, others default to sales
  if (select count(*) from public.user_roles) = 0 then
    insert into public.user_roles (user_id, role) values (new.id, 'super_admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'sales');
  end if;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- updated_at helper
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create trigger profiles_touch before update on public.profiles
  for each row execute function public.touch_updated_at();

-- Leads
create table public.leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  phone text,
  company text,
  source text,
  status public.lead_status not null default 'new',
  priority public.lead_priority not null default 'medium',
  notes text,
  tags text[] not null default '{}',
  follow_up_date timestamptz,
  revenue_value numeric(12,2) default 0,
  assigned_to uuid references auth.users(id) on delete set null,
  starred boolean not null default false,
  pinned boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.leads to authenticated;
grant all on public.leads to service_role;
alter table public.leads enable row level security;
create policy "Leads readable by team" on public.leads for select to authenticated using (true);
create policy "Authenticated can create leads" on public.leads for insert to authenticated with check (auth.uid() = created_by);
create policy "Authenticated can update leads" on public.leads for update to authenticated using (true);
create policy "Admins delete leads" on public.leads for delete to authenticated using (
  public.has_role(auth.uid(), 'admin') or public.has_role(auth.uid(), 'super_admin') or auth.uid() = created_by
);
create trigger leads_touch before update on public.leads for each row execute function public.touch_updated_at();
create index leads_status_idx on public.leads(status);
create index leads_assigned_idx on public.leads(assigned_to);

-- Lead notes
create table public.lead_notes (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.lead_notes to authenticated;
grant all on public.lead_notes to service_role;
alter table public.lead_notes enable row level security;
create policy "Notes readable by team" on public.lead_notes for select to authenticated using (true);
create policy "Authors create notes" on public.lead_notes for insert to authenticated with check (auth.uid() = author_id);
create policy "Authors delete own notes" on public.lead_notes for delete to authenticated using (auth.uid() = author_id);

-- Lead activities (audit log)
create table public.lead_activities (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  type text not null,
  description text,
  meta jsonb,
  created_at timestamptz not null default now()
);
grant select, insert on public.lead_activities to authenticated;
grant all on public.lead_activities to service_role;
alter table public.lead_activities enable row level security;
create policy "Activities readable by team" on public.lead_activities for select to authenticated using (true);
create policy "Authenticated create activities" on public.lead_activities for insert to authenticated with check (true);
create index lead_activities_lead_idx on public.lead_activities(lead_id, created_at desc);
