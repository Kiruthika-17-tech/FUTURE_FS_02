import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Sparkles, BarChart3, KanbanSquare, Users, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nimbus CRM — Lead management for modern teams" },
      { name: "description", content: "Capture, qualify and convert client leads with a premium, futuristic CRM built for agencies, startups and sales teams." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-hero pointer-events-none" />
      <header className="relative z-10 flex items-center justify-between px-6 lg:px-12 py-5">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-primary shadow-glow grid place-items-center">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="font-semibold tracking-tight">Nimbus CRM</span>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild variant="ghost"><Link to="/auth">Sign in</Link></Button>
          <Button asChild className="bg-gradient-primary shadow-glow"><Link to="/auth">Get started</Link></Button>
        </div>
      </header>

      <main className="relative z-10 px-6 lg:px-12 pt-16 pb-24 max-w-6xl mx-auto">
        <div className="animate-fade-in">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/50 backdrop-blur px-3 py-1 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" /> v1 · built for teams that ship
          </span>
          <h1 className="mt-6 text-5xl lg:text-7xl font-semibold tracking-tight leading-[1.05]">
            The CRM that turns<br />
            <span className="bg-gradient-primary bg-clip-text text-transparent">cold leads into clients.</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Capture, qualify and convert with a fast, focused workspace. Pipeline kanban, activity timeline, and analytics — all in one calm interface.
          </p>
          <div className="mt-8 flex gap-3">
            <Button asChild size="lg" className="bg-gradient-primary shadow-glow">
              <Link to="/auth">Start free <ArrowRight className="ml-1 h-4 w-4" /></Link>
            </Button>
            <Button asChild size="lg" variant="outline"><Link to="/auth">Sign in</Link></Button>
          </div>
        </div>

        <section className="mt-24 grid md:grid-cols-3 gap-4">
          {[
            { icon: Users, t: "Lead workspace", d: "Unified table with smart filters, tags, priority and assignment." },
            { icon: KanbanSquare, t: "Visual pipeline", d: "Drag leads across stages from New to Converted." },
            { icon: BarChart3, t: "Live analytics", d: "Conversion, revenue and team performance at a glance." },
          ].map((f) => (
            <div key={f.t} className="glass rounded-2xl p-6 animate-scale-in">
              <f.icon className="h-5 w-5 text-primary" />
              <h3 className="mt-3 font-semibold">{f.t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.d}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}
