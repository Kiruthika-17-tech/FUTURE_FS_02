import type { Database } from "@/integrations/supabase/types";

export type LeadStatus = Database["public"]["Enums"]["lead_status"];
export type LeadPriority = Database["public"]["Enums"]["lead_priority"];
export type AppRole = Database["public"]["Enums"]["app_role"];

export type Lead = Database["public"]["Tables"]["leads"]["Row"];
export type LeadInsert = Database["public"]["Tables"]["leads"]["Insert"];
export type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export const STATUS_META: Record<LeadStatus, { label: string; tone: string }> = {
  new:           { label: "New",           tone: "bg-blue-500/15 text-blue-300 border-blue-500/30" },
  contacted:     { label: "Contacted",     tone: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30" },
  follow_up:     { label: "Follow-up",     tone: "bg-violet-500/15 text-violet-300 border-violet-500/30" },
  qualified:     { label: "Qualified",     tone: "bg-indigo-500/15 text-indigo-300 border-indigo-500/30" },
  proposal_sent: { label: "Proposal Sent", tone: "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-500/30" },
  negotiation:   { label: "Negotiation",   tone: "bg-amber-500/15 text-amber-300 border-amber-500/30" },
  converted:     { label: "Converted",     tone: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  rejected:      { label: "Rejected",      tone: "bg-rose-500/15 text-rose-300 border-rose-500/30" },
};

export const STATUS_ORDER: LeadStatus[] = [
  "new", "contacted", "follow_up", "qualified", "proposal_sent", "negotiation", "converted", "rejected",
];

export const PRIORITY_META: Record<LeadPriority, { label: string; tone: string }> = {
  low:    { label: "Low",    tone: "text-muted-foreground" },
  medium: { label: "Medium", tone: "text-blue-300" },
  high:   { label: "High",   tone: "text-amber-300" },
  urgent: { label: "Urgent", tone: "text-rose-300" },
};

export function initials(name?: string | null) {
  if (!name) return "?";
  return name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
}

export function formatCurrency(n: number | null | undefined) {
  const v = Number(n ?? 0);
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(v);
}